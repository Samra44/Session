<?php
 session_start();
 session_abort();
 header("location:page1.php");




?>