<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page1</title>
</head>
<body>
    <form action="" method ="post">
    <label>username</label>
    <input type="text" name="username"><br><br>
    <label>Password</label>
    <input type="text" name="password">
    <br>
    <input type="submit"value ="login" name="Loginbtn">
    
    <?php
    session_start();
    if(isset($_REQUEST ['Loginbtn'])){
        if($_REQUEST['username'] == "Samrah" && $_REQUEST['password']=="Samrah@123"){
           $_SESSION['username']=$_REQUEST['username'];
           $_SESSION['last_time'] = time();
           header("location:page2.php");
        }
        else{
            header("location:page1.php");
        }
    }
    
    
    ?>

    </form>
</body>
</html>