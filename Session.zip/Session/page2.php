<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Welcome To The Login Page2</h1>

    <?php
    session_start();
    if(isset($_SESSION['username'])){

        if((time()-$_SESSION['last_time'])>60){
            header("location:page1.php");
        }else{
            echo "welcome to PAGE2;" . $_SESSION['username'];
        }
    }else{
        header("location:page1.php");
    }
    
    ?>
    <br><br>
    <a href="page3.php">Go to page3</a>
</body>
</html>